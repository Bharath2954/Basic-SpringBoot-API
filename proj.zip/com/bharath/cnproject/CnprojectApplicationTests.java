package com.bharath.cnproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CnprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
